#!/bin/bash

if [ ! -f "mutex" ]
then
    echo "Nu exista binarul mutex"
    exit
fi

for i in {1..10000}; do ./without_mutex >> output1.txt; done
for i in {1..10000}; do ./mutex >> output2.txt; done

echo "Fara mutex:"
tr '[A-Z]' '[a-z]' < output1.txt | \
     egrep -v "^ *(join date|age|posts|location|re):" | \
     sort | \
     uniq -c

echo "Cu mutex:"
tr '[A-Z]' '[a-z]' < output2.txt | \
     egrep -v "^ *(join date|age|posts|location|re):" | \
     sort | \
     uniq -c

rm output1.txt output2.txt