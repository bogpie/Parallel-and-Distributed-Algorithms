#!/bin/bash

if [ ! -f "mutex" ]
then
    echo "Nu exista binarul mutex"
    exit
fi

for i in {1..10000}; do ./withoutMutex_multiply_inner 3 2 >> output1.txt; done
for i in {1..10000}; do ./multiply_inner 3 2 >> output2.txt; done

echo "Fara mutex linii distincte:"
tr '[A-Z]' '[a-z]' < output1.txt | \
     egrep -v "^ *(join date|age|posts|location|re):" | \
     sort | \
     uniq -c

echo "Cu mutex linii distincte:"
tr '[A-Z]' '[a-z]' < output2.txt | \
     egrep -v "^ *(join date|age|posts|location|re):" | \
     sort | \
     uniq -c

rm output1.txt output2.txt