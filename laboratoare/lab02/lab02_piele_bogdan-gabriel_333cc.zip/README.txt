Realizat de Noaghea Marian si Piele Bogdan

make
make run-1
make run-2-withoutBarrier
make run-2-withBarrier
make run-3
make run-4
make run-5
make run-6
