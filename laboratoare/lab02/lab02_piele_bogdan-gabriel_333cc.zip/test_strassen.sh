#!/bin/bash

N=1000
P=2

if [ ! -f "strassen" ]
then
    echo "Nu exista binarul strassen"
    exit
fi

if [ ! -f "strassen_par" ]
then
    echo "Nu exista binarul strassen_par"
    exit
fi

./strassen $N > output1.txt
./strassen_par $N > output2.txt


DIFF=$(diff output1.txt output2.txt) 
if [ "$DIFF" == "" ] 
then
    echo "Outputul pentru secvential identic cu cel pentru paralel"
fi

rm -rf output1.txt output2.txt